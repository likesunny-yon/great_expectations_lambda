
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.4.0'
version = '1.4.0'
full_version = '1.4.0'
git_revision = 'f533e9103e249ac56654626621aca3ec1bffff0e'
release = True

if not release:
    version = full_version
